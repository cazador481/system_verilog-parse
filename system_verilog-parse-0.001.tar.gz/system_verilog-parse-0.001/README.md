This is incomplete try to system_verilog/uvm completion engine.  

This is written in perl.
The perl module system_verilog::parse is the module that parses a system_verilog project, and creates a sqlite database with packages, variables, and functions.
To parse. my $parser= system_verilog::parse->new(db_file=><location of database>,follow_inc =>1,inc_dirs=>['include 1', 'include 2']);
$parser->parse_file('files');

At this point of time there is no script that will pull the information from the database. So you will need to pull that data out.

