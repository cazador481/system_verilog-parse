OVM examples
------------

This collection of examples illustrates some basic principles of
testbench construction with OVM.

mechanics: shows how to construction object hierarchies, connect to
hardware with virtual interfaces, and a simple transaction-based
producer consumer

tlm: These examples illustrate using the TLM interfaces and channels to
connect testbech components together.

------------------------------------------------------------------------
